import abi from "./Transactions.json";

export const contractAddress = "0x3557d0a9e5CcaFE286F17c3a69E4765a18674119";
export const contractABI = abi.abi;
